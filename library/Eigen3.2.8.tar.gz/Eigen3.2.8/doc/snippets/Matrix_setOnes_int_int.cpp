MatrixXf m;
m.setOnes(3, 3);
cout << m << endl;
